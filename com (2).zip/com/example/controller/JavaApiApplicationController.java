package com.example.controller;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import com.example.beans.JavaApiApplicationBeans;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class JavaApiApplicationController {

        @RequestMapping(method = RequestMethod.GET, value="/data")

        @ResponseBody
        public String getAllStudents() throws NoSuchAlgorithmException, NoSuchProviderException {
            System.out.println(JavaApiApplicationBeans.generateSessionKey().toString());
            return JavaApiApplicationBeans.generateSessionKey().toString();
        }

    }
